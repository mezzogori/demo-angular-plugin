<?php
// Nessun dato persistente da rimuovere.
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }