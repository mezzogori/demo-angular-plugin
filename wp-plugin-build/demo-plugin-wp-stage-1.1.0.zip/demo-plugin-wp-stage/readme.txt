=== demo Plugin WP (STAGE) ===
Contributors: Enrico Mezzogori
Tags: angular, spa
Requires at least: 6.1
Tested up to: 6.6
Stable tag: 1.1.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Incorpora la build Angular in WordPress tramite shortcode.

== Usage ==
1. Carica il plugin .zip su WordPress e attivalo.
2. Crea una pagina e inserisci lo shortcode [demo_plugin_wp_stage].
3. Consigliato: build Angular con "--base-href ./".
